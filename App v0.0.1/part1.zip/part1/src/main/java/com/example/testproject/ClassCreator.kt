package com.example.testproject

class ClassCreator(title: String) {
    val class_label: String = title
}