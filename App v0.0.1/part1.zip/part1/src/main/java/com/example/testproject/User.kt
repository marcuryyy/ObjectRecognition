package com.example.testproject

class User(val login: String, val email: String, val password: String) {
}